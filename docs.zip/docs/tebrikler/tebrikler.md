# :fontawesome-regular-handshake: Tebrikler
Yeni bir tebrik girmek ya da oluşturulmuş tebriklerin görüntülenebileceği ekrandır.

## :fontawesome-regular-handshake: Tebrik Listesi

Oluşturulmuş tebrikler burada gösterilir, düzenlenir ya da silinir.

![](./images/tebrikListesi.jpg)

### Tebrik Düzenle

İlgili tebriğin düzenlenebileceği ekrandır. Sayfadaki özellikler için bkz: [Tebrik Tanımla](#tebrik-tanimla)

### Tebrik Sil

İlgili tebriğin silinmesini sağlar. Tıklanması halinde onay penceresi görünür.

## Tebrik Oluştur

### <a name="tebrik-tanimla"></a>Tebrik Tanımla

| Özellik                  | Açıklama                                                     |
| ------------------------ | ------------------------------------------------------------ |
| Bildirim Gönderme Durumu | Açık olması halinde; haber yayınlandığı anda, alıcı listesinde seçilmiş kişilere bildirim gönderilir. |
| Şablon                   | Önceden hazırlanmış şablonlardan seçim yapılır.              |
| Tebrik Türü              | Ne tür tebrik yapılacağıdır. Tebrik türüne göre ikonlar değişir. |
| Açıklama                 | Tebriğin açıklamasıdır.                                      |
| Aktifleştirme Durumu     | Aktif olması durumunda tebrik görünür, Pasif olması durumunda görünmez. |
| Rozet                    | Tebrik listesinde gösterilecek görseldir.                    |
| Detay Görseli            | Tebrik açıldığında gösterilecek görseldir.                   |
| Yayınlanma Tarihi        | Tebrik, seçilen tarihten sonra görünür olur. Yayınlanma tarihi geldiğinde -aktifleştirildiyse- kullanıcılara bildirim gider. |

### Tebrik Edilecek Kişiler

Tebrik edilecek kullanıcıların ya da kullanıcı gruplarının seçildiği alandır. Kullanıcı ya da gruplar ismine göre aranabilir. **Kaydet ve gönder** butonu tıklandığında -aktifleştirildiyse- seçili alıcılara bildirim gider. Girilen tebrikler tüm kullanıcılar, sisteme kayıtlı tarafından görünür.
