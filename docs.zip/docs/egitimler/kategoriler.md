# :fontawesome-solid-list-alt: Kategoriler

## :fontawesome-solid-list-alt: Kategori Listesi