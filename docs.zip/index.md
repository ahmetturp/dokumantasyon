# Mobil Yaka Kılavuz'a Hoşgeldiniz.

## Mobil Yaka Nedir?

Mobil Yaka çalışanlarla şirketi yakınlaştıran ve her zaman her yerde etkileşim içinde olmalarını sağlayan bir mobil uygulamadır.

Mobil Yaka'nın web sitesine [buraya](https://mobilyaka.com/) tıklayarak ulaşabilirsiniz. Mobil uygulamayı iOS için AppStore ve Android için Google Play Store'dan indirebilirsiniz.

## Mobil Yaka Kılavuz Nedir?

![qrLink](images/qrLink.png){ align=right } Mobil Yaka Kılavuz ile Mobil Yaka web portalındaki özellikler için yardım sayfalarına ulaşabilirsiniz. Yan taraftaki QR kodunu mobil cihazınızdan taratarak kılavuzu mobil cihazlarınızda da görüntüleyebilirsiniz.

Sol tarafta bulunan liste, web portaldaki menü yapısı ile aynıdır. Yardım almak istediğiniz sayfanın ismine tıklayabilirsiniz.

Sağ üst tarafta bulunan arama motoru ile tüm sitede arama yapabilirsiniz.

<img src="images/image-20220107160540620.png" alt="image-20220107160540620" style="zoom: 67%;" />

Arama alanının yanındaki buton ile farklı renk şemaları arasında geçiş yapabilirsiniz.

<img src="images/mobilYakaColors.png" alt="image-20220107160540620" style="zoom: 67%;" />
