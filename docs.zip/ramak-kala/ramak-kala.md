# :fontawesome-solid-indent: Ramak Kala



## :fontawesome-solid-indent: Ramak Kala Listesi

Mobil Yaka uygulamasından gönderilen Ramak Kala kayıtları burada gösterilir ya da silinir. Liste İşlemleri butonu ile Excel, PDF dosyası olarak kaydetme veya yazdırma işlemleri yapılabilir.

!!! tip "İpucu"

    Uygulamadan gönderilen Ramak Kala kayıtlarını e-posta ile alacak yetkililer, Kullanıcı Grupları kısmından ayarlanır. Kullanıcı grubunda "Modül Adı" olarak "Ramak Kala" seçilmesi yeterlidir.

![](images/ramakKala.png)

### Sil

İlgili kaydın silinmesini sağlar. Tıklanması halinde onay penceresi görünür.

## Uygulama İçi Görünümü

??? info "Ramak Kala"

    <iframe width="300" height="533" src="https://xd.adobe.com/embed/a51929be-b754-4dc0-ad0d-97be0156061d-f04a/screen/1c2bcc5d-f0e6-443e-8bba-008f1492cc7e" frameborder="0" ></iframe>
