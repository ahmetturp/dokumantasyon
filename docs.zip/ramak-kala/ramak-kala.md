# :fontawesome-solid-indent: Ramak Kala

## :fontawesome-solid-indent: Ramak Kala Listesi

Mobil Yaka uygulamasından gönderilen Ramak Kala kayıtları burada gösterilir ya da silinir. Liste İşlemleri butonu ile Excel, PDF dosyası olarak kaydetme veya yazdırma işlemleri yapılabilir.

!!! tip "İpucu"

    Uygulamadan gönderilen Ramak Kala kayıtlarını e-posta ile alacak yetkililer, Kullanıcı Grupları kısmından ayarlanır. Kullanıcı grubunda "Modül Adı" olarak "Ramak Kala" seçilmesi yeterlidir.

![](images/ramakKala.png)

### Sil

İlgili kaydın silinmesini sağlar. Tıklanması halinde onay penceresi görünür.
