# :fontawesome-solid-clipboard-list: Öneri

## :fontawesome-solid-clipboard-list: Öneri Listesi

Mobil Yaka uygulamasından gönderilen öneriler burada gösterilir ya da silinir. Liste İşlemleri butonu ile Excel, PDF dosyası olarak kaydetme veya yazdırma işlemleri yapılabilir.

![](images/oneriListesi.png)

### Sil

İlgili kaydın silinmesini sağlar. Tıklanması halinde onay penceresi görünür.
