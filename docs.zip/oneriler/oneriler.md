# :fontawesome-solid-clipboard-list: Öneri

## :fontawesome-solid-clipboard-list: Öneri Listesi

Mobil Yaka uygulamasından gönderilen öneriler burada gösterilir ya da silinir. Liste İşlemleri butonu ile Excel, PDF dosyası olarak kaydetme veya yazdırma işlemleri yapılabilir.

![](images/oneriListesi.png)

### Sil

İlgili kaydın silinmesini sağlar. Tıklanması halinde onay penceresi görünür.

## Uygulama İçi Görünümü

??? info "Öneri Paylaşma"

    <iframe width="300" height="533" src="https://xd.adobe.com/embed/a51929be-b754-4dc0-ad0d-97be0156061d-f04a/screen/68f753d8-6a56-43ca-b208-67d83cfecee2" frameborder="0" ></iframe>
