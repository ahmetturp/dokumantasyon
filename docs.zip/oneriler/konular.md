# :fontawesome-solid-clipboard-list: Konular

## :fontawesome-solid-clipboard-list: Konu Listesi

Mobil Yaka uygulamasında görünecek Öneri kategorileri burada gösterilir, düzenlenir ya da silinir.

![](./images/konuListesi.png)

## Yeni Konu Oluştur

### Konu Tanımla

| Özellik              | Açıklama                                                     |
| -------------------- | ------------------------------------------------------------ |
| Konu Adı             | -                                                            |
| Aktifleştirme Durumu | Aktif olması durumunda konu, Öneri modülünde görünür, Pasif olması durumunda görünmez. |

