# :fontawesome-solid-map-marked-alt: Personel Konum

## :fontawesome-solid-map-marked-alt: Detaylı Arama

Mobil Yaka uygulaması içerisinden Check-in yapmış kullanıcıların listelenmesini sağlar. Detaylı arama sayesinde birden fazla personel, harita üzerinde gösterilir.

![](./images/detayliArama.png)