# :fontawesome-solid-bus: Servis Yönetimi

## :fontawesome-solid-bus: Servisler

Firmanızdaki servis bilgileri oluşturulur, düzenlenir ya da silinir.

### Düzenle

İlgili servisin düzenlenebileceği ekrandır. Sayfadaki özellikler için bkz: [Servis Tanımla](#servis-tanimla)

### Sil

İlgili servisin silinmesini sağlar. Tıklanması halinde onay penceresi görünür.

## Yeni Servis Oluştur

### <a name="servis-tanimla"></a>Servis Tanımla

Yeni bir servis tanımlayı sağlar.

![](./images/servisTanimla.png)

| Özellik    | Açıklama                    |
| ---------- | --------------------------- |
| Servis Adı | -                           |
| İl         | Servisin hizmet verdiği il. |

### Durak Tanımla

Servisin geçeceği duraklar ve sabah/akşam saatleri eklenir.