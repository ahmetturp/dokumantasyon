# :fontawesome-solid-building: Firma Bilgileri

## :fontawesome-solid-building: Şirket Bilgileri

Mobil Yaka uygulamasında, "Hakkımızda" sayfasındaki bilgilerin düzenlenebileceği ekrandır. Uygulama içerisindeki firma logosu, açılış sayfası gibi görseller firmanıza özel güncellenebilir.

| Özellik                                    | Açıklama                                                     |
| ------------------------------------------ | ------------------------------------------------------------ |
| Şirket Adı                                 | -                                                            |
| Adres                                      | -                                                            |
| Telefon                                    | Birden fazla telefon numarası yazılabilir.                   |
| Hakkımızda Metni Üst Kısım                 |                                                              |
| Hakkımızda Metni Alt Kısım                 |                                                              |
| Şirket Bilgi Metni                         |                                                              |
| Vizyon Metni                               |                                                              |
| Misyon Metni                               |                                                              |
| Slogan Metni                               | Mobil Yaka uygulaması açılırken, Mobil Açılış Sayfası imajı ile birlikte bu slogan görüntülenir. |
| Yardım Metni                               |                                                              |
| Mobil Yaka Destek Hizmetleri E-mail Adresi |                                                              |
| Ülke                                       |                                                              |
| Şehir                                      |                                                              |
| Vergi Dairesi                              |                                                              |
| Vergi No                                   |                                                              |
| Ticari Kontak                              |                                                              |
| Ticari Kontak Tel                          |                                                              |
| Ticari Kontak E-mail                       |                                                              |
| Teknik Kontak                              |                                                              |
| Teknik Kontak Tel                          |                                                              |
| Teknik Kontak E-mail                       |                                                              |
| Bildirim Tercihi                           |                                                              |
| Şirket Logo                                |                                                              |
| Mobil Açılış Sayfası                       |                                                              |
| Uygulama İçin Üst Görsel                   |                                                              |
| Slider Görseli                             |                                                              |

