# :fontawesome-solid-building: Firma Bilgileri

## :fontawesome-solid-poll: Raporlar

Mobil Yaka kullanımına ait raporlarların aylık ve haftalık olarak görüntülenebileceği ekrandır. Rapor, Excel ve PDF formatında indirilebilir ya da yazdırılabilir.