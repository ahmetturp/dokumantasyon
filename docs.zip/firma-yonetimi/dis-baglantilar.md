# :fontawesome-solid-building: Firma Bilgileri

## :fontawesome-solid-link: Dış Bağlantılar

Çalışanların sık kullanacağı web siteleri (örneğin firmanızın web sitesi) dış bağlantı olarak eklenebilir. Eklenen dış bağlantılar, Mobil Yaka uygulaması içerisinde sağ taraftaki hamburger menüde görüntülenir.

![](./images/disBaglantilar.png)

### Düzenle

İlgili dış bağlantının düzenlenebileceği ekrandır. Sayfadaki özellikler için bkz: [Dış Bağlantı Tanımla](#dis-baglanti-tanimla)

### Sil

İlgili dış bağlantının silinmesini sağlar. Tıklanması halinde onay penceresi görünür.

## Yeni Dış Bağlantı Oluştur

### <a name="dis-baglanti-tanimla"></a>Dış Bağlantı Tanımla

Yeni bir dış bağlantı oluşturmayı sağlar.

| Özellik           | Açıklama                                                     |
| ----------------- | ------------------------------------------------------------ |
| Başlık            | -                                                            |
| Link Adresi       | -                                                            |
| Görüntüleme Şekli | "Tarayıcıda" seçilmesi halinde link, mobil cihazdaki tarayıcı uygulamasında açılır.<br />"Uygulamada" seçilmesi halinde link, Mobil Yaka uygulamasından çıkmadan, uygulama içerisinde açılır. |

